@echo off
echo Dang bien dich Gia Pha Ho Ngo APK...
call gradle assembleDebug
echo File APK da duoc xuat tai: app\build\outputs\apk\debug\app-debug.apk
pause
