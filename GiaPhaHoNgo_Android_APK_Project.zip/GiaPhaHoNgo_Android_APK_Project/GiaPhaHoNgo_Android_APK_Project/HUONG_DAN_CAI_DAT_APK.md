# Hướng Dẫn Cài Đặt Ứng Dụng Gia Phả Họ Ngô (Android APK & PWA)

Bộ sản phẩm bao gồm:
1. **Ứng dụng trực tuyến / Offline (`app/src/main/assets/index.html`)**: Đã tích hợp trọn vẹn **635 bản ghi thành viên Gia phả Họ Ngô (Đời 1 – Đời 14)** từ Thủy Tổ **Ngô Công Tự Chính Tâm** và **196 hộ gia đình Xuân Tế (5 Tổ)** cùng hệ thống phân quyền 3 cấp.
2. **Mã nguồn dự án Android Studio (`GiaPhaHoNgo_Android_APK_Project`)**: Dùng để xuất file `.apk` cài đặt trực tiếp.

## Cách 1: Cài đặt ngay lên Điện thoại không cần biên dịch (Nhanh nhất - 30 giây)
1. Chuyển file `index.html` (hoặc mở trực tiếp trên trình duyệt Chrome của điện thoại Android / Safari trên iPhone).
2. Bấm vào biểu tượng **Menu 3 chấm (⋮)** ở góc phải trình duyệt Chrome -> Chọn **"Thêm vào màn hình chính" (Add to Home screen / Cài đặt ứng dụng)**.
3. Biểu tượng **Gia Phả Họ Ngô** sẽ xuất hiện trên màn hình điện thoại như một ứng dụng độc lập, tra cứu mượt mà cả khi không có mạng.

## Cách 2: Xuất file `.apk` tự động miễn phí qua GitHub Actions (Không cần cài Android Studio)
1. Tạo 1 kho lưu trữ (Repository) trên GitHub và tải toàn bộ thư mục dự án này lên.
2. Vào tab **Actions** trên GitHub -> Chọn workflow **Build Gia Pha Ho Ngo Android APK** -> Nhấn **Run workflow**.
3. Sau khoảng 2 phút, tải file **`GiaPhaHoNgo-Android-APK.zip`** chứa file `.apk` đã ký sẵn về điện thoại để cài đặt.

## Cách 3: Biên dịch `.apk` trên máy tính bằng Android Studio
1. Mở **Android Studio** -> Chọn **Open** -> Trỏ tới thư mục `GiaPhaHoNgo_Android_APK_Project`.
2. Chọn menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Lấy file `.apk` tại `app/build/outputs/apk/debug/app-debug.apk`.

## Thông Tin Tài Khoản & Mã PIN Phân Quyền Trong Ứng Dụng
- **Cấp 1 — Thành viên / Khách (Mặc định):** Chỉ được phép **Tra cứu** phả hệ 14 đời, xem cây gia phả, tính xưng hô, xem lịch giỗ và gửi **Phiếu đề xuất bổ sung** vào hàng đợi.
- **Cấp 2 — Biên tập viên Chi phái (Mã PIN: `1883`):** Được phép **Thêm thành viên mới (Đời con/cháu)**, **Chỉnh sửa hồ sơ** và **Phê duyệt đề xuất** của thành viên.
- **Cấp 3 — Quản trị Tối cao / Hội đồng Gia tộc (Mã PIN: `2026` hoặc Mật khẩu: `NgoToc@Admin`):** Toàn quyền thêm/sửa/xóa bản ghi, duyệt đề xuất, đổi mã PIN cấp quyền, xem Nhật ký kiểm toán (Audit Log) và Xuất/Nhập cơ sở dữ liệu JSON/CSV.
