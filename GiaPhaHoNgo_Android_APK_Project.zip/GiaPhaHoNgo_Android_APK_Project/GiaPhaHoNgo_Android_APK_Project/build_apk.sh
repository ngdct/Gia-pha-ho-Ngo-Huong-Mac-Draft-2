#!/usr/bin/env bash
set -e
echo "Đang biên dịch Gia Phả Họ Ngô APK..."
gradle assembleDebug
echo "Hoàn tất! File APK nằm tại: app/build/outputs/apk/debug/app-debug.apk"
